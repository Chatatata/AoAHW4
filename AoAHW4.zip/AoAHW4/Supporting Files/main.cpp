//
//  main.cpp
//  AlgoHW2
//
//  Created by Buğra Ekuklu on 31.10.2016.
//  Copyright © 2016 The Digital Warehouse. All rights reserved.
//

#include "../AoAHW4ApplicationDelegate.hpp"

int main(int argc, const char * argv[]) {
    return Application(AoAHW4ApplicationDelegate(), argc, argv);
}
